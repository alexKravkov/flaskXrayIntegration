This package is intended to eventually replace the current `@babel/plugin-transform-react-jsx`, changing the JSX transform from targeting `React.createElement(type, props, children)` to `React.jsx(types, props, key)`. 

https://github.com/reactjs/rfcs/blob/createlement-rfc/text/0000-create-element-changes.md

**This is experimental and not intended to be used directly.**
